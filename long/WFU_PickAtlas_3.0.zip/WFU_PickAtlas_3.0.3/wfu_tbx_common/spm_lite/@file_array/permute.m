function varargout = permute(varargin)
% Can not be permuted.
% _______________________________________________________________________
% Copyright (C) 2008 Wellcome Trust Centre for Neuroimaging

%
% $Id: permute.m,v 1.2 2010/08/30 18:44:27 bwagner Exp $


error('file_array objects can not be permuted.');
