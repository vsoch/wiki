function varargout = ctranspose(varargin)
% Transposing not allowed
% _______________________________________________________________________
% Copyright (C) 2008 Wellcome Trust Centre for Neuroimaging

%
% $Id: ctranspose.m,v 1.2 2010/08/30 18:44:26 bwagner Exp $

error('file_array objects can not be transposed.');
