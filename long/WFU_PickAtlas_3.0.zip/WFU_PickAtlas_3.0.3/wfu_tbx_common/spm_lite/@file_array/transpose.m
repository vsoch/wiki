function varargout = transpose(varargin)
% Transposing is not allowed.
% _______________________________________________________________________
% Copyright (C) 2008 Wellcome Trust Centre for Neuroimaging

%
% $Id: transpose.m,v 1.2 2010/08/30 18:44:27 bwagner Exp $


error('file_array objects can not be transposed.');
