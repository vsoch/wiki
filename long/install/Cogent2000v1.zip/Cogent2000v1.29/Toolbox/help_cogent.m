function help_cogent
% HELP_COGENT lists one-line help on all Cogent functions.
%
% Cogent 2000 function.

disp('COGENT 2000 COMMANDS:');
lookfor 'Cogent 2000' -all
